Intlola
=========

Eclipse plugin for the Impendulo system.
Records snapshots of coding for testing and analysis.
Sends data to server or stores it locally.
Install from http://star.sun.ac.za/~pjordaan/IntlolaSite
